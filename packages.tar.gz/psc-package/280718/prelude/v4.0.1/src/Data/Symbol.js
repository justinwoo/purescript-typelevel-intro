"use strict";

// module Data.Symbol

exports.unsafeCoerce = function (arg) {
  return arg;
};


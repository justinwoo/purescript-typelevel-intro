# purescript-prelude

[![Latest release](http://img.shields.io/github/release/purescript/purescript-prelude.svg)](https://github.com/purescript/purescript-prelude/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-prelude.svg?branch=master)](https://travis-ci.org/purescript/purescript-prelude)

The PureScript prelude.

## Installation

```
bower install purescript-prelude
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-prelude).


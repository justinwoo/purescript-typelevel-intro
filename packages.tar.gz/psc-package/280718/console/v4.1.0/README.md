# purescript-console

[![Latest release](http://img.shields.io/github/release/purescript/purescript-eff.svg)](https://github.com/purescript/purescript-console/releases)
[![Build status](https://travis-ci.org/purescript/purescript-console.svg?branch=master)](https://travis-ci.org/purescript/purescript-console)

Console-related functions and effect type.

## Installation

```
bower install purescript-console
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-console).
